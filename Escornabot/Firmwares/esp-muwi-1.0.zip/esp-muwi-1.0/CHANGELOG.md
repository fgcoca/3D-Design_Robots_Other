
# Changelog

## v1.0 (Jul 27, 2017)

Nuevo:
- Versión inicial
- Conectividad WiFi para el Escornabot
- Mando Universal remoto para cualquier dispositivo
