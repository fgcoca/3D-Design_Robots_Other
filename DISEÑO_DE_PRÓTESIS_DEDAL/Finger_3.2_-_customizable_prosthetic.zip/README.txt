                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


http://www.thingiverse.com/thing:904304
Finger 3.2 - customizable prosthetic by knick is licensed under the Creative Commons - Attribution - Non-Commercial license.
http://creativecommons.org/licenses/by-nc/3.0/

# Summary

<b>UPDATE, 2/14/2016:  This model is now obsolete!</b>
Here's the new one, v3.5 - including a how-to video: http://www.thingiverse.com/thing:1340624

--------------------------------------------------------------------------

The latest of my finger prosthetic efforts, now configurable in OpenSCAD format.  Choose 1 or 2 segments, and preview changes to all parts in rotated or exploded mode.  

See a video in use here: https://youtu.be/lwU__cYSwPI  

I'm still working some of the bugs out to ensure that the design is properly parametric.  If you find that it is not working well with a certain measurement let me know and I'll take a look.  

Update: 11/30/15, I posted a new version 3.2 with many fixes.



# Instructions

Start with preview mode to see changes, and then choose each individual part for printing.  

The base, middle section, tip, and linkage  I print in PLA.  All other parts I do with NinjaFlex.  I use 65# braided finishing line, and thin black elastic cord.   

I can post more detailed instructions soon if folks would find it helpful.